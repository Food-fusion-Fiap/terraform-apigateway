"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const jsonwebtoken_1 = __importDefault(require("jsonwebtoken"));
const pg_1 = require("pg");
// Configuração do ambiente
const env = process.env.NODE_ENV || 'development';
async function getConfig() {
    console.log('Obtendo configurações do banco de dados...');
    if (env === 'development') {
        return {
            RDS_ENDPOINT: 'postgres.cl4qcumy8f7j.us-east-1.rds.amazonaws.com',
            RDS_DATABASE_NAME: 'postgres',
            RDS_USER: 'postgres',
            RDS_PASSWORD: 'foobarbaz',
            JWT_SECRET: 'mysecret',
        };
    }
    const RDS_ENDPOINT = 'postgres.c9emy44wan4g.us-east-1.rds.amazonaws.com';
    console.log('RDS_ENDPOINT:', RDS_ENDPOINT);
    const RDS_DATABASE_NAME = 'postgres';
    const RDS_USER = 'postgres';
    const RDS_PASSWORD = 'rootroot';
    const JWT_SECRET = "mysecret";
    return {
        RDS_ENDPOINT,
        RDS_DATABASE_NAME,
        RDS_USER,
        RDS_PASSWORD,
        JWT_SECRET,
    };
}
// Função Lambda
const handler = async (event) => {
    console.log('Iniciando função Lambda...', event);
    let config;
    // Obter configurações do banco de dados
    try {
        config = await getConfig();
    }
    catch (error) {
        console.error('Erro ao obter configurações do banco de dados:', error);
        return {
            statusCode: 500,
            body: JSON.stringify({ message: 'Ocorreu um erro ao buscar as configurações do banco de dados.' }),
        };
    }
    // Conecta ao banco de dados
    const client = new pg_1.Client({
        host: config.RDS_ENDPOINT,
        database: config.RDS_DATABASE_NAME,
        user: config.RDS_USER,
        password: config.RDS_PASSWORD,
        port: 5432,
        ssl: {
            rejectUnauthorized: false
        }
    });
    try {
        console.log('Conectando ao banco de dados...');
        await client.connect();
    }
    catch (error) {
        console.error('Erro ao conectar ao banco de dados:', error);
        return {
            statusCode: 500,
            body: JSON.stringify({ message: 'Ocorreu um erro ao conectar ao banco de dados.' }),
        };
    }
    console.log('Conexão com o banco de dados estabelecida.');
    try {
        const query = 'SELECT * FROM users WHERE cpf = $1';
        const result = await client.query(query, [event.cpf]);
        const options = {
            expiresIn: '30m', // Token expires in 30 minutes
        };
        let payload = {
            userId: null,
        };
        if (result.rows.length) {
            payload.userId = result.rows[0].id;
        }
        const token = jsonwebtoken_1.default.sign(payload, config.JWT_SECRET, options);
        return {
            statusCode: 200,
            body: JSON.stringify({ token }),
        };
    }
    catch (error) {
        console.error('Erro ao buscar o usuário:', error);
        return {
            statusCode: 500,
            body: JSON.stringify({ message: 'Ocorreu um erro ao buscar o usuário.' }),
        };
    }
    finally {
        await client.end();
    }
};
exports.handler = handler;
if (env === 'development') {
    (0, exports.handler)({ cpf: '12345678900' }).then(console.log);
    (0, exports.handler)({ cpf: '123' }).then(console.log);
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYXV0aGVudGljYXRlLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vYXBwL2F1dGhlbnRpY2F0ZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7QUFBQSxnRUFBK0I7QUFDL0IsMkJBQTRCO0FBRTVCLDJCQUEyQjtBQUMzQixNQUFNLEdBQUcsR0FBRyxPQUFPLENBQUMsR0FBRyxDQUFDLFFBQVEsSUFBSSxhQUFhLENBQUM7QUFFbEQsS0FBSyxVQUFVLFNBQVM7SUFDdEIsT0FBTyxDQUFDLEdBQUcsQ0FBQyw0Q0FBNEMsQ0FBQyxDQUFDO0lBRTFELElBQUksR0FBRyxLQUFLLGFBQWEsRUFBRSxDQUFDO1FBQzFCLE9BQU87WUFDTCxZQUFZLEVBQUUsbURBQW1EO1lBQ2pFLGlCQUFpQixFQUFFLFVBQVU7WUFDN0IsUUFBUSxFQUFFLFVBQVU7WUFDcEIsWUFBWSxFQUFFLFdBQVc7WUFDekIsVUFBVSxFQUFFLFVBQVU7U0FDdkIsQ0FBQTtJQUNILENBQUM7SUFFRCxNQUFNLFlBQVksR0FBRyxtREFBbUQsQ0FBQztJQUN6RSxPQUFPLENBQUMsR0FBRyxDQUFDLGVBQWUsRUFBRSxZQUFZLENBQUMsQ0FBQztJQUMzQyxNQUFNLGlCQUFpQixHQUFHLFVBQVUsQ0FBQztJQUNyQyxNQUFNLFFBQVEsR0FBRyxVQUFVLENBQUM7SUFDNUIsTUFBTSxZQUFZLEdBQUcsVUFBVSxDQUFDO0lBQ2hDLE1BQU0sVUFBVSxHQUFHLFVBQVUsQ0FBQztJQUU5QixPQUFPO1FBQ0wsWUFBWTtRQUNaLGlCQUFpQjtRQUNqQixRQUFRO1FBQ1IsWUFBWTtRQUNaLFVBQVU7S0FDWCxDQUFDO0FBQ0osQ0FBQztBQU1ELGdCQUFnQjtBQUNULE1BQU0sT0FBTyxHQUFHLEtBQUssRUFBRSxLQUFnQixFQUFFLEVBQUU7SUFDaEQsT0FBTyxDQUFDLEdBQUcsQ0FBQyw0QkFBNEIsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUNqRCxJQUFJLE1BQU0sQ0FBQztJQUVYLHdDQUF3QztJQUN4QyxJQUFJLENBQUM7UUFDSCxNQUFNLEdBQUcsTUFBTSxTQUFTLEVBQUUsQ0FBQztJQUM3QixDQUFDO0lBQUMsT0FBTyxLQUFLLEVBQUUsQ0FBQztRQUNmLE9BQU8sQ0FBQyxLQUFLLENBQUMsZ0RBQWdELEVBQUUsS0FBSyxDQUFDLENBQUM7UUFFdkUsT0FBTztZQUNMLFVBQVUsRUFBRSxHQUFHO1lBQ2YsSUFBSSxFQUFFLElBQUksQ0FBQyxTQUFTLENBQUMsRUFBRSxPQUFPLEVBQUUsK0RBQStELEVBQUUsQ0FBQztTQUNuRyxDQUFDO0lBQ0osQ0FBQztJQUVELDRCQUE0QjtJQUM1QixNQUFNLE1BQU0sR0FBRyxJQUFJLFdBQU0sQ0FBQztRQUN4QixJQUFJLEVBQUUsTUFBTSxDQUFDLFlBQVk7UUFDekIsUUFBUSxFQUFFLE1BQU0sQ0FBQyxpQkFBaUI7UUFDbEMsSUFBSSxFQUFFLE1BQU0sQ0FBQyxRQUFRO1FBQ3JCLFFBQVEsRUFBRSxNQUFNLENBQUMsWUFBWTtRQUM3QixJQUFJLEVBQUUsSUFBSTtRQUNWLEdBQUcsRUFBRTtZQUNILGtCQUFrQixFQUFFLEtBQUs7U0FDMUI7S0FDRixDQUFDLENBQUM7SUFFSCxJQUFJLENBQUM7UUFDSCxPQUFPLENBQUMsR0FBRyxDQUFDLGlDQUFpQyxDQUFDLENBQUM7UUFDL0MsTUFBTSxNQUFNLENBQUMsT0FBTyxFQUFFLENBQUM7SUFDekIsQ0FBQztJQUFDLE9BQU8sS0FBSyxFQUFFLENBQUM7UUFDZixPQUFPLENBQUMsS0FBSyxDQUFDLHFDQUFxQyxFQUFFLEtBQUssQ0FBQyxDQUFDO1FBRTVELE9BQU87WUFDTCxVQUFVLEVBQUUsR0FBRztZQUNmLElBQUksRUFBRSxJQUFJLENBQUMsU0FBUyxDQUFDLEVBQUUsT0FBTyxFQUFFLGdEQUFnRCxFQUFFLENBQUM7U0FDcEYsQ0FBQztJQUNKLENBQUM7SUFFRCxPQUFPLENBQUMsR0FBRyxDQUFDLDRDQUE0QyxDQUFDLENBQUM7SUFFMUQsSUFBSSxDQUFDO1FBQ0gsTUFBTSxLQUFLLEdBQUcsb0NBQW9DLENBQUM7UUFDbkQsTUFBTSxNQUFNLEdBQUcsTUFBTSxNQUFNLENBQUMsS0FBSyxDQUFDLEtBQUssRUFBRSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDO1FBRXRELE1BQU0sT0FBTyxHQUFvQjtZQUMvQixTQUFTLEVBQUUsS0FBSyxFQUFFLDhCQUE4QjtTQUNqRCxDQUFDO1FBRUYsSUFBSSxPQUFPLEdBQUc7WUFDWixNQUFNLEVBQUUsSUFBVztTQUNwQixDQUFDO1FBRUYsSUFBSSxNQUFNLENBQUMsSUFBSSxDQUFDLE1BQU0sRUFBRSxDQUFDO1lBQ3ZCLE9BQU8sQ0FBQyxNQUFNLEdBQUcsTUFBTSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7UUFDckMsQ0FBQztRQUVELE1BQU0sS0FBSyxHQUFHLHNCQUFHLENBQUMsSUFBSSxDQUFDLE9BQU8sRUFBRSxNQUFNLENBQUMsVUFBVSxFQUFFLE9BQU8sQ0FBQyxDQUFDO1FBRTVELE9BQU87WUFDTCxVQUFVLEVBQUUsR0FBRztZQUNmLElBQUksRUFBRSxJQUFJLENBQUMsU0FBUyxDQUFDLEVBQUUsS0FBSyxFQUFFLENBQUM7U0FDaEMsQ0FBQztJQUNKLENBQUM7SUFBQyxPQUFPLEtBQUssRUFBRSxDQUFDO1FBQ2YsT0FBTyxDQUFDLEtBQUssQ0FBQywyQkFBMkIsRUFBRSxLQUFLLENBQUMsQ0FBQztRQUVsRCxPQUFPO1lBQ0wsVUFBVSxFQUFFLEdBQUc7WUFDZixJQUFJLEVBQUUsSUFBSSxDQUFDLFNBQVMsQ0FBQyxFQUFFLE9BQU8sRUFBRSxzQ0FBc0MsRUFBRSxDQUFDO1NBQzFFLENBQUM7SUFDSixDQUFDO1lBQVMsQ0FBQztRQUNULE1BQU0sTUFBTSxDQUFDLEdBQUcsRUFBRSxDQUFDO0lBQ3JCLENBQUM7QUFDSCxDQUFDLENBQUM7QUExRVcsUUFBQSxPQUFPLFdBMEVsQjtBQUVGLElBQUksR0FBRyxLQUFLLGFBQWEsRUFBRSxDQUFDO0lBQzFCLElBQUEsZUFBTyxFQUFDLEVBQUUsR0FBRyxFQUFFLGFBQWEsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsQ0FBQztJQUNsRCxJQUFBLGVBQU8sRUFBQyxFQUFFLEdBQUcsRUFBRSxLQUFLLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLENBQUM7QUFDNUMsQ0FBQyJ9