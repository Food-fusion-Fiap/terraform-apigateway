"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const client_ssm_1 = require("@aws-sdk/client-ssm");
const jsonwebtoken_1 = __importDefault(require("jsonwebtoken"));
const pg_1 = require("pg");
// Configuração do ambiente
const env = process.env.NODE_ENV || 'development';
// Configuração do cliente SSM
const ssmClient = new client_ssm_1.SSMClient({ region: 'us-east-1' });
// Função para obter parâmetro do SSM
async function getSSMParameter(parameterName) {
    const command = new client_ssm_1.GetParameterCommand({
        Name: `/food_fusion/${parameterName}`,
        WithDecryption: true,
    });
    const response = await ssmClient.send(command);
    if (!response.Parameter?.Value) {
        throw new Error(`Não foi possível encontrar o parâmetro ${parameterName} no SSM.`);
    }
    return response.Parameter.Value;
}
async function getConfig() {
    console.log('Obtendo configurações do banco de dados...');
    if (env === 'development') {
        return {
            RDS_ENDPOINT: process.env.RDS_ENDPOINT,
            RDS_DATABASE_NAME: process.env.RDS_DATABASE_NAME,
            RDS_USER: process.env.RDS_USER,
            RDS_PASSWORD: process.env.RDS_PASSWORD,
            JWT_SECRET: process.env.JWT_SECRET,
        };
    }
    const RDS_ENDPOINT = 'postgres.c9emy44wan4g.us-east-1.rds.amazonaws.com';
    console.log('RDS_ENDPOINT:', RDS_ENDPOINT);
    const RDS_DATABASE_NAME = 'postgres';
    const RDS_USER = 'postgres';
    const RDS_PASSWORD = 'rootroot';
    const JWT_SECRET = "mysecret";
    return {
        RDS_ENDPOINT,
        RDS_DATABASE_NAME,
        RDS_USER,
        RDS_PASSWORD,
        JWT_SECRET,
    };
}
// Função Lambda
const handler = async (event) => {
    console.log('Iniciando função Lambda...', event);
    let config;
    // Obter configurações do banco de dados
    try {
        config = await getConfig();
        console.log('Configurações do banco de dados', config);
    }
    catch (error) {
        console.error('Erro ao obter configurações do banco de dados:', error);
        return {
            statusCode: 500,
            body: JSON.stringify({ message: 'Ocorreu um erro ao buscar as configurações do banco de dados.' }),
        };
    }
    // Conecta ao banco de dados
    const client = new pg_1.Client({
        host: config.RDS_ENDPOINT,
        database: config.RDS_DATABASE_NAME,
        user: config.RDS_USER,
        password: config.RDS_PASSWORD,
        port: 5432,
        ssl: {
            rejectUnauthorized: false
        }
    });
    try {
        console.log('Conectando ao banco de dados...');
        await client.connect();
    }
    catch (error) {
        console.error('Erro ao conectar ao banco de dados:', error);
        return {
            statusCode: 500,
            body: JSON.stringify({ message: 'Ocorreu um erro ao conectar ao banco de dados.' }),
        };
    }
    console.log('Conexão com o banco de dados estabelecida.');
    try {
        const query = 'SELECT * FROM users WHERE cpf = $1';
        const result = await client.query(query, [event.cpf]);
        const options = {
            expiresIn: '30m', // Token expires in 30 minutes
        };
        let payload = {
            userId: null,
        };
        if (result.rows.length) {
            payload.userId = result.rows[0].id;
        }
        const token = jsonwebtoken_1.default.sign(payload, config.JWT_SECRET, options);
        return {
            statusCode: 200,
            body: token,
        };
    }
    catch (error) {
        console.error('Erro ao buscar o usuário:', error);
        return {
            statusCode: 500,
            body: JSON.stringify({ message: 'Ocorreu um erro ao buscar o usuário.' }),
        };
    }
    finally {
        await client.end();
    }
};
exports.handler = handler;
if (env === 'development') {
    (0, exports.handler)({ cpf: '12345678900' }).then(console.log);
    (0, exports.handler)({ cpf: '123' }).then(console.log);
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYXV0aGVudGljYXRlLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vYXBwL2F1dGhlbnRpY2F0ZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7QUFBQSxvREFBcUU7QUFDckUsZ0VBQStCO0FBQy9CLDJCQUE0QjtBQUU1QiwyQkFBMkI7QUFDM0IsTUFBTSxHQUFHLEdBQUcsT0FBTyxDQUFDLEdBQUcsQ0FBQyxRQUFRLElBQUksYUFBYSxDQUFDO0FBRWxELDhCQUE4QjtBQUM5QixNQUFNLFNBQVMsR0FBRyxJQUFJLHNCQUFTLENBQUMsRUFBRSxNQUFNLEVBQUUsV0FBVyxFQUFFLENBQUMsQ0FBQztBQUV6RCxxQ0FBcUM7QUFDckMsS0FBSyxVQUFVLGVBQWUsQ0FBQyxhQUFxQjtJQUNsRCxNQUFNLE9BQU8sR0FBRyxJQUFJLGdDQUFtQixDQUFDO1FBQ3RDLElBQUksRUFBRSxnQkFBZ0IsYUFBYSxFQUFFO1FBQ3JDLGNBQWMsRUFBRSxJQUFJO0tBQ3JCLENBQUMsQ0FBQztJQUVILE1BQU0sUUFBUSxHQUFHLE1BQU0sU0FBUyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQztJQUUvQyxJQUFJLENBQUMsUUFBUSxDQUFDLFNBQVMsRUFBRSxLQUFLLEVBQUUsQ0FBQztRQUMvQixNQUFNLElBQUksS0FBSyxDQUFDLDBDQUEwQyxhQUFhLFVBQVUsQ0FBQyxDQUFDO0lBQ3JGLENBQUM7SUFFRCxPQUFPLFFBQVEsQ0FBQyxTQUFTLENBQUMsS0FBSyxDQUFDO0FBQ2xDLENBQUM7QUFFRCxLQUFLLFVBQVUsU0FBUztJQUN0QixPQUFPLENBQUMsR0FBRyxDQUFDLDRDQUE0QyxDQUFDLENBQUM7SUFFMUQsSUFBSSxHQUFHLEtBQUssYUFBYSxFQUFFLENBQUM7UUFDMUIsT0FBTztZQUNMLFlBQVksRUFBRSxPQUFPLENBQUMsR0FBRyxDQUFDLFlBQVk7WUFDdEMsaUJBQWlCLEVBQUUsT0FBTyxDQUFDLEdBQUcsQ0FBQyxpQkFBaUI7WUFDaEQsUUFBUSxFQUFFLE9BQU8sQ0FBQyxHQUFHLENBQUMsUUFBUTtZQUM5QixZQUFZLEVBQUUsT0FBTyxDQUFDLEdBQUcsQ0FBQyxZQUFZO1lBQ3RDLFVBQVUsRUFBRSxPQUFPLENBQUMsR0FBRyxDQUFDLFVBQVU7U0FDbkMsQ0FBQTtJQUNILENBQUM7SUFFRCxNQUFNLFlBQVksR0FBRyxtREFBbUQsQ0FBQztJQUN6RSxPQUFPLENBQUMsR0FBRyxDQUFDLGVBQWUsRUFBRSxZQUFZLENBQUMsQ0FBQztJQUMzQyxNQUFNLGlCQUFpQixHQUFHLFVBQVUsQ0FBQztJQUNyQyxNQUFNLFFBQVEsR0FBRyxVQUFVLENBQUM7SUFDNUIsTUFBTSxZQUFZLEdBQUcsVUFBVSxDQUFDO0lBQ2hDLE1BQU0sVUFBVSxHQUFHLFVBQVUsQ0FBQztJQUU5QixPQUFPO1FBQ0wsWUFBWTtRQUNaLGlCQUFpQjtRQUNqQixRQUFRO1FBQ1IsWUFBWTtRQUNaLFVBQVU7S0FDWCxDQUFDO0FBQ0osQ0FBQztBQU1ELGdCQUFnQjtBQUNULE1BQU0sT0FBTyxHQUFHLEtBQUssRUFBRSxLQUFnQixFQUFFLEVBQUU7SUFDaEQsT0FBTyxDQUFDLEdBQUcsQ0FBQyw0QkFBNEIsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUNqRCxJQUFJLE1BQU0sQ0FBQztJQUVYLHdDQUF3QztJQUN4QyxJQUFJLENBQUM7UUFDSCxNQUFNLEdBQUcsTUFBTSxTQUFTLEVBQUUsQ0FBQztRQUMzQixPQUFPLENBQUMsR0FBRyxDQUFDLGlDQUFpQyxFQUFFLE1BQU0sQ0FBQyxDQUFDO0lBQ3pELENBQUM7SUFBQyxPQUFPLEtBQUssRUFBRSxDQUFDO1FBQ2YsT0FBTyxDQUFDLEtBQUssQ0FBQyxnREFBZ0QsRUFBRSxLQUFLLENBQUMsQ0FBQztRQUV2RSxPQUFPO1lBQ0wsVUFBVSxFQUFFLEdBQUc7WUFDZixJQUFJLEVBQUUsSUFBSSxDQUFDLFNBQVMsQ0FBQyxFQUFFLE9BQU8sRUFBRSwrREFBK0QsRUFBRSxDQUFDO1NBQ25HLENBQUM7SUFDSixDQUFDO0lBRUQsNEJBQTRCO0lBQzVCLE1BQU0sTUFBTSxHQUFHLElBQUksV0FBTSxDQUFDO1FBQ3hCLElBQUksRUFBRSxNQUFNLENBQUMsWUFBWTtRQUN6QixRQUFRLEVBQUUsTUFBTSxDQUFDLGlCQUFpQjtRQUNsQyxJQUFJLEVBQUUsTUFBTSxDQUFDLFFBQVE7UUFDckIsUUFBUSxFQUFFLE1BQU0sQ0FBQyxZQUFZO1FBQzdCLElBQUksRUFBRSxJQUFJO1FBQ1YsR0FBRyxFQUFFO1lBQ0gsa0JBQWtCLEVBQUUsS0FBSztTQUMxQjtLQUNGLENBQUMsQ0FBQztJQUVILElBQUksQ0FBQztRQUNILE9BQU8sQ0FBQyxHQUFHLENBQUMsaUNBQWlDLENBQUMsQ0FBQztRQUMvQyxNQUFNLE1BQU0sQ0FBQyxPQUFPLEVBQUUsQ0FBQztJQUN6QixDQUFDO0lBQUMsT0FBTyxLQUFLLEVBQUUsQ0FBQztRQUNmLE9BQU8sQ0FBQyxLQUFLLENBQUMscUNBQXFDLEVBQUUsS0FBSyxDQUFDLENBQUM7UUFFNUQsT0FBTztZQUNMLFVBQVUsRUFBRSxHQUFHO1lBQ2YsSUFBSSxFQUFFLElBQUksQ0FBQyxTQUFTLENBQUMsRUFBRSxPQUFPLEVBQUUsZ0RBQWdELEVBQUUsQ0FBQztTQUNwRixDQUFDO0lBQ0osQ0FBQztJQUVELE9BQU8sQ0FBQyxHQUFHLENBQUMsNENBQTRDLENBQUMsQ0FBQztJQUUxRCxJQUFJLENBQUM7UUFDSCxNQUFNLEtBQUssR0FBRyxvQ0FBb0MsQ0FBQztRQUNuRCxNQUFNLE1BQU0sR0FBRyxNQUFNLE1BQU0sQ0FBQyxLQUFLLENBQUMsS0FBSyxFQUFFLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUM7UUFFdEQsTUFBTSxPQUFPLEdBQW9CO1lBQy9CLFNBQVMsRUFBRSxLQUFLLEVBQUUsOEJBQThCO1NBQ2pELENBQUM7UUFFRixJQUFJLE9BQU8sR0FBWTtZQUNyQixNQUFNLEVBQUUsSUFBVztTQUNwQixDQUFDO1FBRUYsSUFBSSxNQUFNLENBQUMsSUFBSSxDQUFDLE1BQU0sRUFBRSxDQUFDO1lBQ3ZCLE9BQU8sQ0FBQyxNQUFNLEdBQUcsTUFBTSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7UUFDckMsQ0FBQztRQUVELE1BQU0sS0FBSyxHQUFHLHNCQUFHLENBQUMsSUFBSSxDQUFDLE9BQU8sRUFBRSxNQUFNLENBQUMsVUFBVSxFQUFFLE9BQU8sQ0FBQyxDQUFDO1FBRTVELE9BQU87WUFDTCxVQUFVLEVBQUUsR0FBRztZQUNmLElBQUksRUFBRSxLQUFLO1NBQ1osQ0FBQztJQUNKLENBQUM7SUFBQyxPQUFPLEtBQUssRUFBRSxDQUFDO1FBQ2YsT0FBTyxDQUFDLEtBQUssQ0FBQywyQkFBMkIsRUFBRSxLQUFLLENBQUMsQ0FBQztRQUVsRCxPQUFPO1lBQ0wsVUFBVSxFQUFFLEdBQUc7WUFDZixJQUFJLEVBQUUsSUFBSSxDQUFDLFNBQVMsQ0FBQyxFQUFFLE9BQU8sRUFBRSxzQ0FBc0MsRUFBRSxDQUFDO1NBQzFFLENBQUM7SUFDSixDQUFDO1lBQVMsQ0FBQztRQUNULE1BQU0sTUFBTSxDQUFDLEdBQUcsRUFBRSxDQUFDO0lBQ3JCLENBQUM7QUFDSCxDQUFDLENBQUM7QUEzRVcsUUFBQSxPQUFPLFdBMkVsQjtBQUVGLElBQUksR0FBRyxLQUFLLGFBQWEsRUFBRSxDQUFDO0lBQzFCLElBQUEsZUFBTyxFQUFDLEVBQUUsR0FBRyxFQUFFLGFBQWEsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsQ0FBQztJQUNsRCxJQUFBLGVBQU8sRUFBQyxFQUFFLEdBQUcsRUFBRSxLQUFLLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLENBQUM7QUFDNUMsQ0FBQyJ9