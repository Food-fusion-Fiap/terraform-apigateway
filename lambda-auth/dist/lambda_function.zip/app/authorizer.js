"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const handler = async (event) => {
    console.log("Init lambda authorizer...");
    console.log({ event });
    const DenyPolicy = {
        "Version": "2012-10-17",
        "Statement": [
            {
                "Action": "execute-api:Invoke",
                "Effect": "Deny",
                "Resource": event.methodArn,
            }
        ]
    };
    const AllowPolicy = {
        "Version": "2012-10-17",
        "Statement": [
            {
                "Action": "execute-api:Invoke",
                "Effect": "Allow",
                "Resource": event.methodArn,
            }
        ]
    };
    let response = {
        principalId: "user",
        policyDocument: DenyPolicy,
        context: {
            "userID": null,
        }
    };
    if (event.authorizationToken == "secretToken") {
        console.log("allowed");
        response.policyDocument = AllowPolicy;
        response.context.userID = null;
    }
    console.log("Returning lambda authorizer response");
    console.log(response);
    return response;
};
exports.handler = handler;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYXV0aG9yaXplci5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uL2FwcC9hdXRob3JpemVyLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7OztBQUFPLE1BQU0sT0FBTyxHQUFHLEtBQUssRUFBQyxLQUFzQixFQUErQixFQUFFO0lBQ2hGLE9BQU8sQ0FBQyxHQUFHLENBQUMsMkJBQTJCLENBQUMsQ0FBQTtJQUN4QyxPQUFPLENBQUMsR0FBRyxDQUFDLEVBQUMsS0FBSyxFQUFDLENBQUMsQ0FBQTtJQUVwQixNQUFNLFVBQVUsR0FBRztRQUNmLFNBQVMsRUFBRSxZQUFZO1FBQ3ZCLFdBQVcsRUFBRTtZQUNUO2dCQUNJLFFBQVEsRUFBRSxvQkFBb0I7Z0JBQzlCLFFBQVEsRUFBRSxNQUFNO2dCQUNoQixVQUFVLEVBQUUsS0FBSyxDQUFDLFNBQVM7YUFDOUI7U0FDSjtLQUNKLENBQUE7SUFFRCxNQUFNLFdBQVcsR0FBRztRQUNoQixTQUFTLEVBQUUsWUFBWTtRQUN2QixXQUFXLEVBQUU7WUFDVDtnQkFDSSxRQUFRLEVBQUUsb0JBQW9CO2dCQUM5QixRQUFRLEVBQUUsT0FBTztnQkFDakIsVUFBVSxFQUFFLEtBQUssQ0FBQyxTQUFTO2FBQzlCO1NBQ0o7S0FDSixDQUFBO0lBRUQsSUFBSSxRQUFRLEdBQXVCO1FBQy9CLFdBQVcsRUFBRSxNQUFNO1FBQ25CLGNBQWMsRUFBRSxVQUFVO1FBQzFCLE9BQU8sRUFBRTtZQUNMLFFBQVEsRUFBRSxJQUFJO1NBQ2pCO0tBQ0osQ0FBQztJQUVGLElBQUksS0FBSyxDQUFDLGtCQUFrQixJQUFJLGFBQWEsRUFBRSxDQUFDO1FBQzVDLE9BQU8sQ0FBQyxHQUFHLENBQUMsU0FBUyxDQUFDLENBQUM7UUFDdkIsUUFBUSxDQUFDLGNBQWMsR0FBRyxXQUFXLENBQUM7UUFDdEMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxNQUFNLEdBQUcsSUFBSSxDQUFDO0lBQ25DLENBQUM7SUFFRCxPQUFPLENBQUMsR0FBRyxDQUFDLHNDQUFzQyxDQUFDLENBQUE7SUFDbkQsT0FBTyxDQUFDLEdBQUcsQ0FBQyxRQUFRLENBQUMsQ0FBQTtJQUNyQixPQUFPLFFBQVEsQ0FBQztBQUNwQixDQUFDLENBQUM7QUEzQ1csUUFBQSxPQUFPLFdBMkNsQiJ9