"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const jsonwebtoken_1 = __importDefault(require("jsonwebtoken"));
const JWT_SECRET = "my_secret";
const handler = async (event) => {
    console.log("Init lambda authorizer...");
    console.log({ event });
    const DenyPolicy = {
        "Version": "2012-10-17",
        "Statement": [
            {
                "Action": "execute-api:Invoke",
                "Effect": "Deny",
                "Resource": event.methodArn,
            }
        ]
    };
    const AllowPolicy = {
        "Version": "2012-10-17",
        "Statement": [
            {
                "Action": "execute-api:Invoke",
                "Effect": "Allow",
                "Resource": event.methodArn,
            }
        ]
    };
    let response = {
        principalId: "user",
        policyDocument: AllowPolicy,
        context: {
            "userId": null,
        }
    };
    jsonwebtoken_1.default.verify(event.authorizationToken, JWT_SECRET, function (err, decoded) {
        console.log("Verifying JWT...");
        console.log({ decoded });
        if (err) {
            return response;
        }
        else {
            let context = {
                "userId": 1,
            };
            response.policyDocument = AllowPolicy;
            response.context = context;
            return response;
        }
    });
    console.log("Returning lambda authorizer response");
    console.log(response);
    return response;
};
exports.handler = handler;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYXV0aG9yaXplci5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uL2FwcC9hdXRob3JpemVyLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7OztBQUFBLGdFQUErQjtBQUMvQixNQUFNLFVBQVUsR0FBRyxXQUFXLENBQUE7QUFFdkIsTUFBTSxPQUFPLEdBQUcsS0FBSyxFQUFDLEtBQXNCLEVBQStCLEVBQUU7SUFDbEYsT0FBTyxDQUFDLEdBQUcsQ0FBQywyQkFBMkIsQ0FBQyxDQUFBO0lBQ3hDLE9BQU8sQ0FBQyxHQUFHLENBQUMsRUFBQyxLQUFLLEVBQUMsQ0FBQyxDQUFBO0lBRXBCLE1BQU0sVUFBVSxHQUFHO1FBQ2pCLFNBQVMsRUFBRSxZQUFZO1FBQ3ZCLFdBQVcsRUFBRTtZQUNYO2dCQUNFLFFBQVEsRUFBRSxvQkFBb0I7Z0JBQzlCLFFBQVEsRUFBRSxNQUFNO2dCQUNoQixVQUFVLEVBQUUsS0FBSyxDQUFDLFNBQVM7YUFDNUI7U0FDRjtLQUNGLENBQUE7SUFFRCxNQUFNLFdBQVcsR0FBRztRQUNsQixTQUFTLEVBQUUsWUFBWTtRQUN2QixXQUFXLEVBQUU7WUFDWDtnQkFDRSxRQUFRLEVBQUUsb0JBQW9CO2dCQUM5QixRQUFRLEVBQUUsT0FBTztnQkFDakIsVUFBVSxFQUFFLEtBQUssQ0FBQyxTQUFTO2FBQzVCO1NBQ0Y7S0FDRixDQUFBO0lBRUQsSUFBSSxRQUFRLEdBQXVCO1FBQ2pDLFdBQVcsRUFBRSxNQUFNO1FBQ25CLGNBQWMsRUFBRSxXQUFXO1FBQzNCLE9BQU8sRUFBRTtZQUNQLFFBQVEsRUFBRSxJQUFJO1NBQ2Y7S0FDRixDQUFDO0lBR0Ysc0JBQUcsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLGtCQUFrQixFQUFFLFVBQVUsRUFBRSxVQUFTLEdBQUcsRUFBRSxPQUFPO1FBQ3BFLE9BQU8sQ0FBQyxHQUFHLENBQUMsa0JBQWtCLENBQUMsQ0FBQTtRQUMvQixPQUFPLENBQUMsR0FBRyxDQUFDLEVBQUMsT0FBTyxFQUFDLENBQUMsQ0FBQTtRQUV0QixJQUFJLEdBQUcsRUFBRSxDQUFDO1lBQ1IsT0FBTyxRQUFRLENBQUE7UUFDakIsQ0FBQzthQUFNLENBQUM7WUFDTixJQUFJLE9BQU8sR0FBRztnQkFDWixRQUFRLEVBQUUsQ0FBQzthQUNaLENBQUE7WUFDRCxRQUFRLENBQUMsY0FBYyxHQUFHLFdBQVcsQ0FBQTtZQUNyQyxRQUFRLENBQUMsT0FBTyxHQUFHLE9BQU8sQ0FBQTtZQUMxQixPQUFPLFFBQVEsQ0FBQTtRQUNqQixDQUFDO0lBQ0gsQ0FBQyxDQUFDLENBQUM7SUFFSCxPQUFPLENBQUMsR0FBRyxDQUFDLHNDQUFzQyxDQUFDLENBQUE7SUFDbkQsT0FBTyxDQUFDLEdBQUcsQ0FBQyxRQUFRLENBQUMsQ0FBQTtJQUNyQixPQUFPLFFBQVEsQ0FBQztBQUNsQixDQUFDLENBQUM7QUF0RFcsUUFBQSxPQUFPLFdBc0RsQiJ9