"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const client_ssm_1 = require("@aws-sdk/client-ssm");
const jsonwebtoken_1 = __importDefault(require("jsonwebtoken"));
const pg_1 = require("pg");
// Configuração do ambiente
const env = process.env.NODE_ENV || 'development';
// Configuração do cliente SSM
const ssmClient = new client_ssm_1.SSMClient({ region: 'us-east-1' });
// Função para obter parâmetro do SSM
async function getSSMParameter(parameterName) {
    const command = new client_ssm_1.GetParameterCommand({
        Name: `/food_fusion/${parameterName}`,
        WithDecryption: true,
    });
    const response = await ssmClient.send(command);
    if (!response.Parameter?.Value) {
        throw new Error(`Não foi possível encontrar o parâmetro ${parameterName} no SSM.`);
    }
    return response.Parameter.Value;
}
async function getConfig() {
    console.log('Obtendo configurações do banco de dados...');
    if (env === 'development') {
        return {
            RDS_ENDPOINT: process.env.RDS_ENDPOINT,
            RDS_DATABASE_NAME: process.env.RDS_DATABASE_NAME,
            RDS_USER: process.env.RDS_USER,
            RDS_PASSWORD: process.env.RDS_PASSWORD,
            JWT_SECRET: process.env.JWT_SECRET,
        };
    }
    const RDS_ENDPOINT = (await getSSMParameter('db_host')).replace(':5432', '');
    const RDS_DATABASE_NAME = await getSSMParameter('db_name');
    const RDS_USER = await getSSMParameter('db_username');
    const RDS_PASSWORD = await getSSMParameter('db_password');
    const JWT_SECRET = await getSSMParameter('jwt_secret');
    return {
        RDS_ENDPOINT,
        RDS_DATABASE_NAME,
        RDS_USER,
        RDS_PASSWORD,
        JWT_SECRET,
    };
}
// Função Lambda
const handler = async (event) => {
    console.log('Iniciando função Lambda...', event);
    let config;
    // Obter configurações do banco de dados
    try {
        config = await getConfig();
        console.log('Configurações do banco de dados', config);
    }
    catch (error) {
        console.error('Erro ao obter configurações do banco de dados:', error);
        return {
            statusCode: 500,
            body: JSON.stringify({ message: 'Ocorreu um erro ao buscar as configurações do banco de dados.' }),
        };
    }
    // Conecta ao banco de dados
    const client = new pg_1.Client({
        host: config.RDS_ENDPOINT,
        database: config.RDS_DATABASE_NAME,
        user: config.RDS_USER,
        password: config.RDS_PASSWORD,
        port: 5432,
        ssl: {
            rejectUnauthorized: false
        }
    });
    try {
        console.log('Conectando ao banco de dados...');
        await client.connect();
    }
    catch (error) {
        console.error('Erro ao conectar ao banco de dados:', error);
        return {
            statusCode: 500,
            body: JSON.stringify({ message: 'Ocorreu um erro ao conectar ao banco de dados.' }),
        };
    }
    console.log('Conexão com o banco de dados estabelecida.');
    try {
        const query = 'SELECT * FROM users WHERE cpf = $1';
        const result = await client.query(query, [event.cpf]);
        const options = {
            expiresIn: '30m', // Token expires in 30 minutes
        };
        let payload = {
            userId: null,
        };
        if (result.rows.length) {
            payload.userId = result.rows[0].id;
        }
        const token = jsonwebtoken_1.default.sign(payload, config.JWT_SECRET, options);
        return {
            statusCode: 200,
            body: token,
        };
    }
    catch (error) {
        console.error('Erro ao buscar o usuário:', error);
        return {
            statusCode: 500,
            body: JSON.stringify({ message: 'Ocorreu um erro ao buscar o usuário.' }),
        };
    }
    finally {
        await client.end();
    }
};
exports.handler = handler;
if (env === 'development') {
    (0, exports.handler)({ cpf: '12345678900' }).then(console.log);
    (0, exports.handler)({ cpf: '123' }).then(console.log);
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5kZXguanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi9hcHAvaW5kZXgudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7O0FBQUEsb0RBQXFFO0FBQ3JFLGdFQUErQjtBQUMvQiwyQkFBNEI7QUFFNUIsMkJBQTJCO0FBQzNCLE1BQU0sR0FBRyxHQUFHLE9BQU8sQ0FBQyxHQUFHLENBQUMsUUFBUSxJQUFJLGFBQWEsQ0FBQztBQUVsRCw4QkFBOEI7QUFDOUIsTUFBTSxTQUFTLEdBQUcsSUFBSSxzQkFBUyxDQUFDLEVBQUUsTUFBTSxFQUFFLFdBQVcsRUFBRSxDQUFDLENBQUM7QUFFekQscUNBQXFDO0FBQ3JDLEtBQUssVUFBVSxlQUFlLENBQUMsYUFBcUI7SUFDbEQsTUFBTSxPQUFPLEdBQUcsSUFBSSxnQ0FBbUIsQ0FBQztRQUN0QyxJQUFJLEVBQUUsZ0JBQWdCLGFBQWEsRUFBRTtRQUNyQyxjQUFjLEVBQUUsSUFBSTtLQUNyQixDQUFDLENBQUM7SUFFSCxNQUFNLFFBQVEsR0FBRyxNQUFNLFNBQVMsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUM7SUFFL0MsSUFBSSxDQUFDLFFBQVEsQ0FBQyxTQUFTLEVBQUUsS0FBSyxFQUFFO1FBQzlCLE1BQU0sSUFBSSxLQUFLLENBQUMsMENBQTBDLGFBQWEsVUFBVSxDQUFDLENBQUM7S0FDcEY7SUFFRCxPQUFPLFFBQVEsQ0FBQyxTQUFTLENBQUMsS0FBSyxDQUFDO0FBQ2xDLENBQUM7QUFFRCxLQUFLLFVBQVUsU0FBUztJQUN0QixPQUFPLENBQUMsR0FBRyxDQUFDLDRDQUE0QyxDQUFDLENBQUM7SUFFMUQsSUFBSSxHQUFHLEtBQUssYUFBYSxFQUFFO1FBQ3pCLE9BQU87WUFDTCxZQUFZLEVBQUUsT0FBTyxDQUFDLEdBQUcsQ0FBQyxZQUFZO1lBQ3RDLGlCQUFpQixFQUFFLE9BQU8sQ0FBQyxHQUFHLENBQUMsaUJBQWlCO1lBQ2hELFFBQVEsRUFBRSxPQUFPLENBQUMsR0FBRyxDQUFDLFFBQVE7WUFDOUIsWUFBWSxFQUFFLE9BQU8sQ0FBQyxHQUFHLENBQUMsWUFBWTtZQUN0QyxVQUFVLEVBQUUsT0FBTyxDQUFDLEdBQUcsQ0FBQyxVQUFVO1NBQ25DLENBQUE7S0FDRjtJQUVELE1BQU0sWUFBWSxHQUFHLENBQUMsTUFBTSxlQUFlLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsT0FBTyxFQUFFLEVBQUUsQ0FBQyxDQUFDO0lBQzdFLE1BQU0saUJBQWlCLEdBQUcsTUFBTSxlQUFlLENBQUMsU0FBUyxDQUFDLENBQUM7SUFDM0QsTUFBTSxRQUFRLEdBQUcsTUFBTSxlQUFlLENBQUMsYUFBYSxDQUFDLENBQUM7SUFDdEQsTUFBTSxZQUFZLEdBQUcsTUFBTSxlQUFlLENBQUMsYUFBYSxDQUFDLENBQUM7SUFDMUQsTUFBTSxVQUFVLEdBQUcsTUFBTSxlQUFlLENBQUMsWUFBWSxDQUFDLENBQUM7SUFFdkQsT0FBTztRQUNMLFlBQVk7UUFDWixpQkFBaUI7UUFDakIsUUFBUTtRQUNSLFlBQVk7UUFDWixVQUFVO0tBQ1gsQ0FBQztBQUNKLENBQUM7QUFNRCxnQkFBZ0I7QUFDVCxNQUFNLE9BQU8sR0FBRyxLQUFLLEVBQUUsS0FBZ0IsRUFBRSxFQUFFO0lBQ2hELE9BQU8sQ0FBQyxHQUFHLENBQUMsNEJBQTRCLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDakQsSUFBSSxNQUFNLENBQUM7SUFFWCx3Q0FBd0M7SUFDeEMsSUFBSTtRQUNGLE1BQU0sR0FBRyxNQUFNLFNBQVMsRUFBRSxDQUFDO1FBQzNCLE9BQU8sQ0FBQyxHQUFHLENBQUMsaUNBQWlDLEVBQUUsTUFBTSxDQUFDLENBQUM7S0FDeEQ7SUFBQyxPQUFPLEtBQUssRUFBRTtRQUNkLE9BQU8sQ0FBQyxLQUFLLENBQUMsZ0RBQWdELEVBQUUsS0FBSyxDQUFDLENBQUM7UUFFdkUsT0FBTztZQUNMLFVBQVUsRUFBRSxHQUFHO1lBQ2YsSUFBSSxFQUFFLElBQUksQ0FBQyxTQUFTLENBQUMsRUFBRSxPQUFPLEVBQUUsK0RBQStELEVBQUUsQ0FBQztTQUNuRyxDQUFDO0tBQ0g7SUFFRCw0QkFBNEI7SUFDNUIsTUFBTSxNQUFNLEdBQUcsSUFBSSxXQUFNLENBQUM7UUFDeEIsSUFBSSxFQUFFLE1BQU0sQ0FBQyxZQUFZO1FBQ3pCLFFBQVEsRUFBRSxNQUFNLENBQUMsaUJBQWlCO1FBQ2xDLElBQUksRUFBRSxNQUFNLENBQUMsUUFBUTtRQUNyQixRQUFRLEVBQUUsTUFBTSxDQUFDLFlBQVk7UUFDN0IsSUFBSSxFQUFFLElBQUk7UUFDVixHQUFHLEVBQUU7WUFDSCxrQkFBa0IsRUFBRSxLQUFLO1NBQzFCO0tBQ0YsQ0FBQyxDQUFDO0lBRUgsSUFBSTtRQUNGLE9BQU8sQ0FBQyxHQUFHLENBQUMsaUNBQWlDLENBQUMsQ0FBQztRQUMvQyxNQUFNLE1BQU0sQ0FBQyxPQUFPLEVBQUUsQ0FBQztLQUN4QjtJQUFDLE9BQU8sS0FBSyxFQUFFO1FBQ2QsT0FBTyxDQUFDLEtBQUssQ0FBQyxxQ0FBcUMsRUFBRSxLQUFLLENBQUMsQ0FBQztRQUU1RCxPQUFPO1lBQ0wsVUFBVSxFQUFFLEdBQUc7WUFDZixJQUFJLEVBQUUsSUFBSSxDQUFDLFNBQVMsQ0FBQyxFQUFFLE9BQU8sRUFBRSxnREFBZ0QsRUFBRSxDQUFDO1NBQ3BGLENBQUM7S0FDSDtJQUVELE9BQU8sQ0FBQyxHQUFHLENBQUMsNENBQTRDLENBQUMsQ0FBQztJQUUxRCxJQUFJO1FBQ0YsTUFBTSxLQUFLLEdBQUcsb0NBQW9DLENBQUM7UUFDbkQsTUFBTSxNQUFNLEdBQUcsTUFBTSxNQUFNLENBQUMsS0FBSyxDQUFDLEtBQUssRUFBRSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDO1FBRXRELE1BQU0sT0FBTyxHQUFvQjtZQUMvQixTQUFTLEVBQUUsS0FBSyxFQUFFLDhCQUE4QjtTQUNqRCxDQUFDO1FBRUYsSUFBSSxPQUFPLEdBQUc7WUFDWixNQUFNLEVBQUUsSUFBVztTQUNwQixDQUFDO1FBRUYsSUFBSSxNQUFNLENBQUMsSUFBSSxDQUFDLE1BQU0sRUFBRTtZQUN0QixPQUFPLENBQUMsTUFBTSxHQUFHLE1BQU0sQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO1NBQ3BDO1FBRUQsTUFBTSxLQUFLLEdBQUcsc0JBQUcsQ0FBQyxJQUFJLENBQUMsT0FBTyxFQUFFLE1BQU0sQ0FBQyxVQUFVLEVBQUUsT0FBTyxDQUFDLENBQUM7UUFFNUQsT0FBTztZQUNMLFVBQVUsRUFBRSxHQUFHO1lBQ2YsSUFBSSxFQUFFLEtBQUs7U0FDWixDQUFDO0tBQ0g7SUFBQyxPQUFPLEtBQUssRUFBRTtRQUNkLE9BQU8sQ0FBQyxLQUFLLENBQUMsMkJBQTJCLEVBQUUsS0FBSyxDQUFDLENBQUM7UUFFbEQsT0FBTztZQUNMLFVBQVUsRUFBRSxHQUFHO1lBQ2YsSUFBSSxFQUFFLElBQUksQ0FBQyxTQUFTLENBQUMsRUFBRSxPQUFPLEVBQUUsc0NBQXNDLEVBQUUsQ0FBQztTQUMxRSxDQUFDO0tBQ0g7WUFBUztRQUNSLE1BQU0sTUFBTSxDQUFDLEdBQUcsRUFBRSxDQUFDO0tBQ3BCO0FBQ0gsQ0FBQyxDQUFDO0FBM0VXLFFBQUEsT0FBTyxXQTJFbEI7QUFFRixJQUFJLEdBQUcsS0FBSyxhQUFhLEVBQUU7SUFDekIsSUFBQSxlQUFPLEVBQUMsRUFBRSxHQUFHLEVBQUUsYUFBYSxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxDQUFDO0lBQ2xELElBQUEsZUFBTyxFQUFDLEVBQUUsR0FBRyxFQUFFLEtBQUssRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsQ0FBQztDQUMzQyJ9