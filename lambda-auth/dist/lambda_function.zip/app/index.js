"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const jsonwebtoken_1 = __importDefault(require("jsonwebtoken"));
const pg_1 = require("pg");
// Configuração do ambiente
const env = process.env.NODE_ENV || 'development';
async function getConfig() {
    console.log('Obtendo configurações do banco de dados...');
    if (env === 'development') {
        return {
            RDS_ENDPOINT: 'postgres.cl4qcumy8f7j.us-east-1.rds.amazonaws.com',
            RDS_DATABASE_NAME: 'postgres',
            RDS_USER: 'postgres',
            RDS_PASSWORD: 'foobarbaz',
            JWT_SECRET: 'mysecret',
        };
    }
    const RDS_ENDPOINT = 'postgres.c9emy44wan4g.us-east-1.rds.amazonaws.com';
    console.log('RDS_ENDPOINT:', RDS_ENDPOINT);
    const RDS_DATABASE_NAME = 'postgres';
    const RDS_USER = 'postgres';
    const RDS_PASSWORD = 'rootroot';
    const JWT_SECRET = "mysecret";
    return {
        RDS_ENDPOINT,
        RDS_DATABASE_NAME,
        RDS_USER,
        RDS_PASSWORD,
        JWT_SECRET,
    };
}
// Função Lambda
const handler = async (event) => {
    console.log('Iniciando função Lambda...', event);
    let config;
    // Obter configurações do banco de dados
    try {
        config = await getConfig();
    }
    catch (error) {
        console.error('Erro ao obter configurações do banco de dados:', error);
        return {
            statusCode: 500,
            body: JSON.stringify({ message: 'Ocorreu um erro ao buscar as configurações do banco de dados.' }),
        };
    }
    // Conecta ao banco de dados
    const client = new pg_1.Client({
        host: config.RDS_ENDPOINT,
        database: config.RDS_DATABASE_NAME,
        user: config.RDS_USER,
        password: config.RDS_PASSWORD,
        port: 5432,
        ssl: {
            rejectUnauthorized: false
        }
    });
    try {
        console.log('Conectando ao banco de dados...');
        await client.connect();
    }
    catch (error) {
        console.error('Erro ao conectar ao banco de dados:', error);
        return {
            statusCode: 500,
            body: JSON.stringify({ message: 'Ocorreu um erro ao conectar ao banco de dados.' }),
        };
    }
    console.log('Conexão com o banco de dados estabelecida.');
    try {
        const query = 'SELECT * FROM users WHERE cpf = $1';
        const result = await client.query(query, [event.cpf]);
        const options = {
            expiresIn: '30m', // Token expires in 30 minutes
        };
        let payload = {
            userId: null,
        };
        if (result.rows.length) {
            payload.userId = result.rows[0].id;
        }
        const token = jsonwebtoken_1.default.sign(payload, config.JWT_SECRET, options);
        return {
            statusCode: 200,
            body: JSON.stringify({ token }),
        };
    }
    catch (error) {
        console.error('Erro ao buscar o usuário:', error);
        return {
            statusCode: 500,
            body: JSON.stringify({ message: 'Ocorreu um erro ao buscar o usuário.' }),
        };
    }
    finally {
        await client.end();
    }
};
exports.handler = handler;
if (env === 'development') {
    (0, exports.handler)({ cpf: '12345678900' }).then(console.log);
    (0, exports.handler)({ cpf: '123' }).then(console.log);
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5kZXguanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi9hcHAvaW5kZXgudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7O0FBQUEsZ0VBQStCO0FBQy9CLDJCQUE0QjtBQUU1QiwyQkFBMkI7QUFDM0IsTUFBTSxHQUFHLEdBQUcsT0FBTyxDQUFDLEdBQUcsQ0FBQyxRQUFRLElBQUksYUFBYSxDQUFDO0FBRWxELEtBQUssVUFBVSxTQUFTO0lBQ3RCLE9BQU8sQ0FBQyxHQUFHLENBQUMsNENBQTRDLENBQUMsQ0FBQztJQUUxRCxJQUFJLEdBQUcsS0FBSyxhQUFhLEVBQUUsQ0FBQztRQUMxQixPQUFPO1lBQ0wsWUFBWSxFQUFFLG1EQUFtRDtZQUNqRSxpQkFBaUIsRUFBRSxVQUFVO1lBQzdCLFFBQVEsRUFBRSxVQUFVO1lBQ3BCLFlBQVksRUFBRSxXQUFXO1lBQ3pCLFVBQVUsRUFBRSxVQUFVO1NBQ3ZCLENBQUE7SUFDSCxDQUFDO0lBRUQsTUFBTSxZQUFZLEdBQUcsbURBQW1ELENBQUM7SUFDekUsT0FBTyxDQUFDLEdBQUcsQ0FBQyxlQUFlLEVBQUUsWUFBWSxDQUFDLENBQUM7SUFDM0MsTUFBTSxpQkFBaUIsR0FBRyxVQUFVLENBQUM7SUFDckMsTUFBTSxRQUFRLEdBQUcsVUFBVSxDQUFDO0lBQzVCLE1BQU0sWUFBWSxHQUFHLFVBQVUsQ0FBQztJQUNoQyxNQUFNLFVBQVUsR0FBRyxVQUFVLENBQUM7SUFFOUIsT0FBTztRQUNMLFlBQVk7UUFDWixpQkFBaUI7UUFDakIsUUFBUTtRQUNSLFlBQVk7UUFDWixVQUFVO0tBQ1gsQ0FBQztBQUNKLENBQUM7QUFNRCxnQkFBZ0I7QUFDVCxNQUFNLE9BQU8sR0FBRyxLQUFLLEVBQUUsS0FBZ0IsRUFBRSxFQUFFO0lBQ2hELE9BQU8sQ0FBQyxHQUFHLENBQUMsNEJBQTRCLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDakQsSUFBSSxNQUFNLENBQUM7SUFFWCx3Q0FBd0M7SUFDeEMsSUFBSSxDQUFDO1FBQ0gsTUFBTSxHQUFHLE1BQU0sU0FBUyxFQUFFLENBQUM7SUFDN0IsQ0FBQztJQUFDLE9BQU8sS0FBSyxFQUFFLENBQUM7UUFDZixPQUFPLENBQUMsS0FBSyxDQUFDLGdEQUFnRCxFQUFFLEtBQUssQ0FBQyxDQUFDO1FBRXZFLE9BQU87WUFDTCxVQUFVLEVBQUUsR0FBRztZQUNmLElBQUksRUFBRSxJQUFJLENBQUMsU0FBUyxDQUFDLEVBQUUsT0FBTyxFQUFFLCtEQUErRCxFQUFFLENBQUM7U0FDbkcsQ0FBQztJQUNKLENBQUM7SUFFRCw0QkFBNEI7SUFDNUIsTUFBTSxNQUFNLEdBQUcsSUFBSSxXQUFNLENBQUM7UUFDeEIsSUFBSSxFQUFFLE1BQU0sQ0FBQyxZQUFZO1FBQ3pCLFFBQVEsRUFBRSxNQUFNLENBQUMsaUJBQWlCO1FBQ2xDLElBQUksRUFBRSxNQUFNLENBQUMsUUFBUTtRQUNyQixRQUFRLEVBQUUsTUFBTSxDQUFDLFlBQVk7UUFDN0IsSUFBSSxFQUFFLElBQUk7UUFDVixHQUFHLEVBQUU7WUFDSCxrQkFBa0IsRUFBRSxLQUFLO1NBQzFCO0tBQ0YsQ0FBQyxDQUFDO0lBRUgsSUFBSSxDQUFDO1FBQ0gsT0FBTyxDQUFDLEdBQUcsQ0FBQyxpQ0FBaUMsQ0FBQyxDQUFDO1FBQy9DLE1BQU0sTUFBTSxDQUFDLE9BQU8sRUFBRSxDQUFDO0lBQ3pCLENBQUM7SUFBQyxPQUFPLEtBQUssRUFBRSxDQUFDO1FBQ2YsT0FBTyxDQUFDLEtBQUssQ0FBQyxxQ0FBcUMsRUFBRSxLQUFLLENBQUMsQ0FBQztRQUU1RCxPQUFPO1lBQ0wsVUFBVSxFQUFFLEdBQUc7WUFDZixJQUFJLEVBQUUsSUFBSSxDQUFDLFNBQVMsQ0FBQyxFQUFFLE9BQU8sRUFBRSxnREFBZ0QsRUFBRSxDQUFDO1NBQ3BGLENBQUM7SUFDSixDQUFDO0lBRUQsT0FBTyxDQUFDLEdBQUcsQ0FBQyw0Q0FBNEMsQ0FBQyxDQUFDO0lBRTFELElBQUksQ0FBQztRQUNILE1BQU0sS0FBSyxHQUFHLG9DQUFvQyxDQUFDO1FBQ25ELE1BQU0sTUFBTSxHQUFHLE1BQU0sTUFBTSxDQUFDLEtBQUssQ0FBQyxLQUFLLEVBQUUsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQztRQUV0RCxNQUFNLE9BQU8sR0FBb0I7WUFDL0IsU0FBUyxFQUFFLEtBQUssRUFBRSw4QkFBOEI7U0FDakQsQ0FBQztRQUVGLElBQUksT0FBTyxHQUFHO1lBQ1osTUFBTSxFQUFFLElBQVc7U0FDcEIsQ0FBQztRQUVGLElBQUksTUFBTSxDQUFDLElBQUksQ0FBQyxNQUFNLEVBQUUsQ0FBQztZQUN2QixPQUFPLENBQUMsTUFBTSxHQUFHLE1BQU0sQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO1FBQ3JDLENBQUM7UUFFRCxNQUFNLEtBQUssR0FBRyxzQkFBRyxDQUFDLElBQUksQ0FBQyxPQUFPLEVBQUUsTUFBTSxDQUFDLFVBQVUsRUFBRSxPQUFPLENBQUMsQ0FBQztRQUU1RCxPQUFPO1lBQ0wsVUFBVSxFQUFFLEdBQUc7WUFDZixJQUFJLEVBQUUsSUFBSSxDQUFDLFNBQVMsQ0FBQyxFQUFFLEtBQUssRUFBRSxDQUFDO1NBQ2hDLENBQUM7SUFDSixDQUFDO0lBQUMsT0FBTyxLQUFLLEVBQUUsQ0FBQztRQUNmLE9BQU8sQ0FBQyxLQUFLLENBQUMsMkJBQTJCLEVBQUUsS0FBSyxDQUFDLENBQUM7UUFFbEQsT0FBTztZQUNMLFVBQVUsRUFBRSxHQUFHO1lBQ2YsSUFBSSxFQUFFLElBQUksQ0FBQyxTQUFTLENBQUMsRUFBRSxPQUFPLEVBQUUsc0NBQXNDLEVBQUUsQ0FBQztTQUMxRSxDQUFDO0lBQ0osQ0FBQztZQUFTLENBQUM7UUFDVCxNQUFNLE1BQU0sQ0FBQyxHQUFHLEVBQUUsQ0FBQztJQUNyQixDQUFDO0FBQ0gsQ0FBQyxDQUFDO0FBMUVXLFFBQUEsT0FBTyxXQTBFbEI7QUFFRixJQUFJLEdBQUcsS0FBSyxhQUFhLEVBQUUsQ0FBQztJQUMxQixJQUFBLGVBQU8sRUFBQyxFQUFFLEdBQUcsRUFBRSxhQUFhLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLENBQUM7SUFDbEQsSUFBQSxlQUFPLEVBQUMsRUFBRSxHQUFHLEVBQUUsS0FBSyxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxDQUFDO0FBQzVDLENBQUMifQ==