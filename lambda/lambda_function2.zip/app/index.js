"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
require("source-map-support/register");
const client_ssm_1 = require("@aws-sdk/client-ssm");
const pg_1 = require("pg");
// Configuração do ambiente
const env = process.env.NODE_ENV || 'development';
// Configuração do cliente SSM
const ssmClient = new client_ssm_1.SSMClient({ region: 'us-east-1' });
// Função para obter parâmetro do SSM
async function getSSMParameter(parameterName) {
    const command = new client_ssm_1.GetParameterCommand({
        Name: `/food_fusion/${parameterName}`,
        WithDecryption: true,
    });
    const response = await ssmClient.send(command);
    if (!response.Parameter?.Value) {
        throw new Error(`Não foi possível encontrar o parâmetro ${parameterName} no SSM.`);
    }
    return response.Parameter.Value;
}
async function getConfig() {
    if (env === 'development') {
        return {
            RDS_ENDPOINT: 'postgres.cl4qcumy8f7j.us-east-1.rds.amazonaws.com',
            RDS_DATABASE_NAME: 'postgres',
            RDS_USER: 'postgres',
            RDS_PASSWORD: 'foobarbaz',
        };
    }
    console.log('Obtendo configurações do banco de dados...');
    const RDS_ENDPOINT = 'postgres.cao4mee9fcpi.us-east-1.rds.amazonaws.com:5432';
    console.log('RDS_ENDPOINT:', RDS_ENDPOINT);
    const RDS_DATABASE_NAME = 'postgres';
    const RDS_USER = 'postgres';
    const RDS_PASSWORD = 'rootroot';
    return {
        RDS_ENDPOINT,
        RDS_DATABASE_NAME,
        RDS_USER,
        RDS_PASSWORD,
    };
}
// Função Lambda
const handler = async (event) => {
    console.log('Iniciando função Lambda...', event);
    let config;
    // Obter configurações do banco de dados
    try {
        config = await getConfig();
        console.log('Configurações do banco de dados:', config);
    }
    catch (error) {
        console.error('Erro ao obter configurações do banco de dados:', error);
        return {
            statusCode: 500,
            body: JSON.stringify({ message: 'Ocorreu um erro ao buscar as configurações do banco de dados.' }),
        };
    }
    // Conecta ao banco de dados
    const client = new pg_1.Client({
        host: config.RDS_ENDPOINT,
        database: config.RDS_DATABASE_NAME,
        user: config.RDS_USER,
        password: config.RDS_PASSWORD,
        port: 5432,
        ssl: {
            rejectUnauthorized: false
        }
    });
    try {
        await client.connect();
    }
    catch (error) {
        console.error('Erro ao conectar ao banco de dados:', error);
        throw error;
    }
    console.log('Conexão com o banco de dados estabelecida.');
    try {
        const query = 'SELECT * FROM users WHERE cpf = $1';
        const result = await client.query(query, [event.cpf]);
        if (result.rows.length === 0) {
            return {
                statusCode: 404,
                body: JSON.stringify({ message: 'Usuário não encontrado.' }),
            };
        }
        return {
            statusCode: 200,
            body: JSON.stringify(result.rows),
        };
    }
    catch (error) {
        return {
            statusCode: 500,
            body: JSON.stringify({ message: 'Ocorreu um erro ao buscar o usuário.' }),
        };
    }
    finally {
        await client.end();
    }
};
exports.handler = handler;
if (env === 'development') {
    (0, exports.handler)({ cpf: '12345678900' }).then(console.log);
    (0, exports.handler)({ cpf: '123' }).then(console.log);
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5kZXguanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi9hcHAvaW5kZXgudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7O0FBQUEsdUNBQXFDO0FBQ3JDLG9EQUFxRTtBQUNyRSwyQkFBNEI7QUFFNUIsMkJBQTJCO0FBQzNCLE1BQU0sR0FBRyxHQUFHLE9BQU8sQ0FBQyxHQUFHLENBQUMsUUFBUSxJQUFJLGFBQWEsQ0FBQztBQUVsRCw4QkFBOEI7QUFDOUIsTUFBTSxTQUFTLEdBQUcsSUFBSSxzQkFBUyxDQUFDLEVBQUUsTUFBTSxFQUFFLFdBQVcsRUFBRSxDQUFDLENBQUM7QUFFekQscUNBQXFDO0FBQ3JDLEtBQUssVUFBVSxlQUFlLENBQUMsYUFBcUI7SUFDbEQsTUFBTSxPQUFPLEdBQUcsSUFBSSxnQ0FBbUIsQ0FBQztRQUN0QyxJQUFJLEVBQUUsZ0JBQWdCLGFBQWEsRUFBRTtRQUNyQyxjQUFjLEVBQUUsSUFBSTtLQUNyQixDQUFDLENBQUM7SUFFSCxNQUFNLFFBQVEsR0FBRyxNQUFNLFNBQVMsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUM7SUFFL0MsSUFBSSxDQUFDLFFBQVEsQ0FBQyxTQUFTLEVBQUUsS0FBSyxFQUFFLENBQUM7UUFDL0IsTUFBTSxJQUFJLEtBQUssQ0FBQywwQ0FBMEMsYUFBYSxVQUFVLENBQUMsQ0FBQztJQUNyRixDQUFDO0lBRUQsT0FBTyxRQUFRLENBQUMsU0FBUyxDQUFDLEtBQUssQ0FBQztBQUNsQyxDQUFDO0FBRUQsS0FBSyxVQUFVLFNBQVM7SUFDdEIsSUFBSSxHQUFHLEtBQUssYUFBYSxFQUFFLENBQUM7UUFDMUIsT0FBTztZQUNMLFlBQVksRUFBRSxtREFBbUQ7WUFDakUsaUJBQWlCLEVBQUUsVUFBVTtZQUM3QixRQUFRLEVBQUUsVUFBVTtZQUNwQixZQUFZLEVBQUUsV0FBVztTQUMxQixDQUFBO0lBQ0gsQ0FBQztJQUVELE9BQU8sQ0FBQyxHQUFHLENBQUMsNENBQTRDLENBQUMsQ0FBQztJQUUxRCxNQUFNLFlBQVksR0FBRyx3REFBd0QsQ0FBQztJQUM5RSxPQUFPLENBQUMsR0FBRyxDQUFDLGVBQWUsRUFBRSxZQUFZLENBQUMsQ0FBQztJQUMzQyxNQUFNLGlCQUFpQixHQUFHLFVBQVUsQ0FBQztJQUNyQyxNQUFNLFFBQVEsR0FBRyxVQUFVLENBQUM7SUFDNUIsTUFBTSxZQUFZLEdBQUcsVUFBVSxDQUFDO0lBRWhDLE9BQU87UUFDTCxZQUFZO1FBQ1osaUJBQWlCO1FBQ2pCLFFBQVE7UUFDUixZQUFZO0tBQ2IsQ0FBQztBQUNKLENBQUM7QUFNRCxnQkFBZ0I7QUFDVCxNQUFNLE9BQU8sR0FBRyxLQUFLLEVBQUUsS0FBZ0IsRUFBRSxFQUFFO0lBQ2hELE9BQU8sQ0FBQyxHQUFHLENBQUMsNEJBQTRCLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFFakQsSUFBSSxNQUFNLENBQUM7SUFFWCx3Q0FBd0M7SUFDeEMsSUFBSSxDQUFDO1FBQ0gsTUFBTSxHQUFHLE1BQU0sU0FBUyxFQUFFLENBQUM7UUFFM0IsT0FBTyxDQUFDLEdBQUcsQ0FBQyxrQ0FBa0MsRUFBRSxNQUFNLENBQUMsQ0FBQztJQUMxRCxDQUFDO0lBQUMsT0FBTyxLQUFLLEVBQUUsQ0FBQztRQUNmLE9BQU8sQ0FBQyxLQUFLLENBQUMsZ0RBQWdELEVBQUUsS0FBSyxDQUFDLENBQUM7UUFDdkUsT0FBTztZQUNMLFVBQVUsRUFBRSxHQUFHO1lBQ2YsSUFBSSxFQUFFLElBQUksQ0FBQyxTQUFTLENBQUMsRUFBRSxPQUFPLEVBQUUsK0RBQStELEVBQUUsQ0FBQztTQUNuRyxDQUFDO0lBQ0osQ0FBQztJQUVELDRCQUE0QjtJQUM1QixNQUFNLE1BQU0sR0FBRyxJQUFJLFdBQU0sQ0FBQztRQUN4QixJQUFJLEVBQUUsTUFBTSxDQUFDLFlBQVk7UUFDekIsUUFBUSxFQUFFLE1BQU0sQ0FBQyxpQkFBaUI7UUFDbEMsSUFBSSxFQUFFLE1BQU0sQ0FBQyxRQUFRO1FBQ3JCLFFBQVEsRUFBRSxNQUFNLENBQUMsWUFBWTtRQUM3QixJQUFJLEVBQUUsSUFBSTtRQUNWLEdBQUcsRUFBRTtZQUNILGtCQUFrQixFQUFFLEtBQUs7U0FDMUI7S0FDRixDQUFDLENBQUM7SUFFSCxJQUFJLENBQUM7UUFDSCxNQUFNLE1BQU0sQ0FBQyxPQUFPLEVBQUUsQ0FBQztJQUN6QixDQUFDO0lBQUMsT0FBTyxLQUFLLEVBQUUsQ0FBQztRQUNmLE9BQU8sQ0FBQyxLQUFLLENBQUMscUNBQXFDLEVBQUUsS0FBSyxDQUFDLENBQUM7UUFFNUQsTUFBTSxLQUFLLENBQUM7SUFDZCxDQUFDO0lBRUQsT0FBTyxDQUFDLEdBQUcsQ0FBQyw0Q0FBNEMsQ0FBQyxDQUFDO0lBRTFELElBQUksQ0FBQztRQUNILE1BQU0sS0FBSyxHQUFHLG9DQUFvQyxDQUFDO1FBQ25ELE1BQU0sTUFBTSxHQUFHLE1BQU0sTUFBTSxDQUFDLEtBQUssQ0FBQyxLQUFLLEVBQUUsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQztRQUV0RCxJQUFJLE1BQU0sQ0FBQyxJQUFJLENBQUMsTUFBTSxLQUFLLENBQUMsRUFBRSxDQUFDO1lBQzdCLE9BQU87Z0JBQ0wsVUFBVSxFQUFFLEdBQUc7Z0JBQ2YsSUFBSSxFQUFFLElBQUksQ0FBQyxTQUFTLENBQUMsRUFBRSxPQUFPLEVBQUUseUJBQXlCLEVBQUUsQ0FBQzthQUM3RCxDQUFDO1FBQ0osQ0FBQztRQUVELE9BQU87WUFDTCxVQUFVLEVBQUUsR0FBRztZQUNmLElBQUksRUFBRSxJQUFJLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUM7U0FDbEMsQ0FBQztJQUNKLENBQUM7SUFBQyxPQUFPLEtBQUssRUFBRSxDQUFDO1FBQ2YsT0FBTztZQUNMLFVBQVUsRUFBRSxHQUFHO1lBQ2YsSUFBSSxFQUFFLElBQUksQ0FBQyxTQUFTLENBQUMsRUFBRSxPQUFPLEVBQUUsc0NBQXNDLEVBQUUsQ0FBQztTQUMxRSxDQUFDO0lBQ0osQ0FBQztZQUFTLENBQUM7UUFDVCxNQUFNLE1BQU0sQ0FBQyxHQUFHLEVBQUUsQ0FBQztJQUNyQixDQUFDO0FBQ0gsQ0FBQyxDQUFDO0FBL0RXLFFBQUEsT0FBTyxXQStEbEI7QUFFRixJQUFJLEdBQUcsS0FBSyxhQUFhLEVBQUUsQ0FBQztJQUMxQixJQUFBLGVBQU8sRUFBQyxFQUFFLEdBQUcsRUFBRSxhQUFhLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLENBQUM7SUFDbEQsSUFBQSxlQUFPLEVBQUMsRUFBRSxHQUFHLEVBQUUsS0FBSyxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxDQUFDO0FBQzVDLENBQUMifQ==